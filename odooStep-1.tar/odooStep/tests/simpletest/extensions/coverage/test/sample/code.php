<?php
// sample code
$x = 1 + 2;
if (false) {
    echo "dead";
}
