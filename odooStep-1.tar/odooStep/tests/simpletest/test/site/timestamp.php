<?php
    print time();
