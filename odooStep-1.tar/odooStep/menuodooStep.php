﻿<?php
global $G_TMP_MENU;


// http://wiki.processmaker.com/3.0/Internal_Functions_and_Classes#Menu::AddIdRawOption.28.29
$G_TMP_MENU->AddIdRawOption("ID_ODOOSTEP_MNU_01", "odooStep/sc_main", "Odoo Steps Creator");
$G_TMP_MENU->AddIdRawOption("ID_ODOOSTEP_MNU_02", "odooStep/cp_main", "Odoo Config"); // TODO Colocarlo en Settings



?>