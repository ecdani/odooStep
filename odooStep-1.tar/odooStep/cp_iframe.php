<iframe src="../odooStep/cp_app" frameborder="0" width="100%" height="260"></iframe>
<iframe src="../odooStep/tests/all_tests" frameborder="0" width="100%" height="600"></iframe>